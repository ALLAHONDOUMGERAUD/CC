
import java.io.*;
import java.util.*;

/**
 * 
 */
public class agent {

    /**
     * Default constructor
     */
    public agent() {
    }

    /**
     * 
     */
    public void matricule;

    /**
     * 
     */
    public void nom;

    /**
     * 
     */
    public void prenom;

    /**
     * 
     */
    public void date de naissance;

    /**
     * 
     */
    public void date de recrutement;

}