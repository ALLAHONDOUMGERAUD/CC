
import java.io.*;
import java.util.*;

/**
 * 
 */
public class classe {

    /**
     * Default constructor
     */
    public classe() {
    }

    /**
     * 
     */
    public void date_tâche;

    /**
     * 
     */
    public void titre_tâche;

    /**
     * 
     */
    public void description_tâche;

    /**
     * 
     */
    public void datePévueDebut_tâche;

    /**
     * 
     */
    public void DatePrévueFin_tâche;

    /**
     * 
     */
    public void DateEffectiveDebut_tâche;

    /**
     * 
     */
    public void DateEffectiveFin_tâche;

    /**
     * 
     */
    public void démarer_tâche() {
        // TODO implement here
    }

    /**
     * 
     */
    public void terminer_tâche() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtenir etat avancement() {
        // TODO implement here
    }

}