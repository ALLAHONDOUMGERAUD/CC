
import java.io.*;
import java.util.*;

/**
 * 
 */
public class equipe {

    /**
     * Default constructor
     */
    public equipe() {
    }

    /**
     * 
     */
    public void Id_équipe;

    /**
     * 
     */
    public void nom_équipe;

}