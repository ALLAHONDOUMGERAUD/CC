
import java.io.*;
import java.util.*;

/**
 * 
 */
public class produit {

    /**
     * Default constructor
     */
    public produit() {
    }

    /**
     * 
     */
    public void Id_produit;

    /**
     * 
     */
    public void type_produit;

    /**
     * 
     */
    public void description_produit;

}