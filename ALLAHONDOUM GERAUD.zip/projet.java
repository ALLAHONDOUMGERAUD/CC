
import java.io.*;
import java.util.*;

/**
 * 
 */
public class projet {

    /**
     * Default constructor
     */
    public projet() {
    }

    /**
     * 
     */
    public void Id_projet;

    /**
     * 
     */
    public void nom_projet;

    /**
     * 
     */
    public void descripton_projet;

    /**
     * 
     */
    public void dateDébut_projet;

    /**
     * 
     */
    public void dateFin_projet;

    /**
     * 
     */
    public void ajouter tache() {
        // TODO implement here
    }

    /**
     * 
     */
    public void générer rapport() {
        // TODO implement here
    }

}