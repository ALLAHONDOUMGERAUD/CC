
import java.io.*;
import java.util.*;

/**
 * 
 */
public class ressources humaines {

    /**
     * Default constructor
     */
    public ressources humaines() {
    }

    /**
     * 
     */
    public void matricule;

    /**
     * 
     */
    public void nom;

    /**
     * 
     */
    public void prénom;

    /**
     * 
     */
    public void date de naissance;

    /**
     * 
     */
    public void qualification;

}