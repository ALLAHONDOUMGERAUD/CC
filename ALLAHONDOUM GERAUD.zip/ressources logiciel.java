
import java.io.*;
import java.util.*;

/**
 * 
 */
public class ressources logiciel {

    /**
     * Default constructor
     */
    public ressources logiciel() {
    }

    /**
     * 
     */
    public void nom;

}