
import java.io.*;
import java.util.*;

/**
 * 
 */
public class ressources matériel {

    /**
     * Default constructor
     */
    public ressources matériel() {
    }

    /**
     * 
     */
    public void identification;

    /**
     * 
     */
    public void type;

}