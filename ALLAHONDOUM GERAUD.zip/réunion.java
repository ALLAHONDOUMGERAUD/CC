
import java.io.*;
import java.util.*;

/**
 * 
 */
public class réunion {

    /**
     * Default constructor
     */
    public réunion() {
    }

    /**
     * 
     */
    public void date_réunions;

    /**
     * 
     */
    public void rapport_réunios;

    /**
     * 
     */
    public void tâche() {
        // TODO implement here
    }

}